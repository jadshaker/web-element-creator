import Div from './Checkbox.css';

const Checkbox = props => (
    <Div
        size={props.size}
        on_color={props.onColor}
        offColor={props.offColor}
        borderColor={props.borderColor}
        hoverColor={props.hoverColor}
    >
        <label>
            <input type="checkbox" />
            <span />
        </label>
    </Div>
);
export default Checkbox;
